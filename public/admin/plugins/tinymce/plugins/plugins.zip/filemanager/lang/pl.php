<?php
define('lang_Select','Wybierz');
define('lang_Erase','Wyczyść');
define('lang_Open','Otwórz');
define('lang_Confirm_del','Czy aby na pewno chcesz usunąć ten plik?');
define('lang_All','Wszystkie');
define('lang_Files','Pliki');
define('lang_Images','Zdjęcia');
define('lang_Archives','Archiwa');
define('lang_Error_Upload','Plik przekracza maksymalny dozwolony rozmiar.');
define('lang_Error_extension','Niedozwolone rozszerzenie pliku.');
define('lang_Upload_file','Wgraj plik');
define('lang_Filter','Filtr');
define('lang_Videos','Filmy');
define('lang_Music','Muzyka');
define('lang_New_Folder','Nowy folder');
define('lang_Folder_Created','Folder został utworzony poprawnie');
define('lang_Existing_Folder','Istniejący f older');
define('lang_Confirm_Folder_del','Czy jesteś pewien, że chcesz usunąć folder i wszystko co znajduje się w nim?');
define('lang_Return_Files_List','Powróć do listy plików');
define('lang_Preview','Podgląd');
define('lang_Download','Pobierz');
define('lang_Insert_Folder_Name','Podaj nazwę folderu:');
define('lang_Root','root');
?>
